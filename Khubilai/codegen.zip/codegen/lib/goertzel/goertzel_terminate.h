/*
 * File: goertzel_terminate.h
 *
 * MATLAB Coder version            : 26.2
 * C/C++ source code generated on  : 14-Oct-2026 13:41:59
 */

#ifndef GOERTZEL_TERMINATE_H
#define GOERTZEL_TERMINATE_H

/* Include Files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
extern void goertzel_terminate(void);

#ifdef __cplusplus
}
#endif

#endif
/*
 * File trailer for goertzel_terminate.h
 *
 * [EOF]
 */
