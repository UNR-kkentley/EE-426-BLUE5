/*
 * File: main.c
 *
 * MATLAB Coder version            : 26.2
 * C/C++ source code generated on  : 14-Oct-2026 13:41:59
 */

/*************************************************************************/
/* This automatically generated example C main file shows how to call    */
/* entry-point functions that MATLAB Coder generated. You must customize */
/* this file for your application. Do not modify this file directly.     */
/* Instead, make a copy of this file, modify it, and integrate it into   */
/* your development environment.                                         */
/*                                                                       */
/* This file initializes entry-point function arguments to a default     */
/* size and value before calling the entry-point functions. It does      */
/* not store or use any values returned from the entry-point functions.  */
/* If necessary, it does pre-allocate memory for returned values.        */
/* You can use this file as a starting point for a main function that    */
/* you can deploy in your application.                                   */
/*                                                                       */
/* After you copy the file, and before you deploy it, you must make the  */
/* following changes:                                                    */
/* * For variable-size function arguments, change the example sizes to   */
/* the sizes that your application requires.                             */
/* * Change the example values of function arguments to the values that  */
/* your application requires.                                            */
/* * If the entry-point functions return values, store these values or   */
/* otherwise use them as required by your application.                   */
/*                                                                       */
/*************************************************************************/

/* Include Files */
#include "main.h"
#include "goertzel.h"
#include "goertzel_initialize.h"
#include "goertzel_terminate.h"
#include "rt_nonfinite.h"

/* Function Declarations */
static void argInit_128x1_real_T(double result[128]);

static double argInit_real_T(void);

/* Function Definitions */
/*
 * Arguments    : double result[128]
 * Return Type  : void
 */
static void argInit_128x1_real_T(double result[128])
{
  int idx0;
  /* Loop over the array to initialize each element. */
  for (idx0 = 0; idx0 < 128; idx0++) {
    /* Set the value of the array element.
Change this value to the value that the application requires. */
    result[idx0] = argInit_real_T();
  }
}

/*
 * Arguments    : void
 * Return Type  : double
 */
static double argInit_real_T(void)
{
  return 0.0;
}

/*
 * Arguments    : int argc
 *                char **argv
 * Return Type  : int
 */
int main(int argc, char **argv)
{
  (void)argc;
  (void)argv;
  /* Initialize the application.
You do not need to do this more than one time. */
  goertzel_initialize();
  /* Invoke the entry-point functions.
You can call entry-point functions multiple times. */
  main_goertzel();
  /* Terminate the application.
You do not need to do this more than one time. */
  goertzel_terminate();
  return 0;
}

/*
 * Arguments    : void
 * Return Type  : void
 */
void main_goertzel(void)
{
  creal_T Y;
  double dv[128];
  /* Initialize function 'goertzel' input arguments. */
  /* Initialize function input argument 'X'. */
  /* Call the entry-point 'goertzel'. */
  argInit_128x1_real_T(dv);
  Y = goertzel(dv, argInit_real_T());
}

/*
 * File trailer for main.c
 *
 * [EOF]
 */
