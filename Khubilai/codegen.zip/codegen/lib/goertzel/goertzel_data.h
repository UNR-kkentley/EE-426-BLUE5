/*
 * File: goertzel_data.h
 *
 * MATLAB Coder version            : 26.2
 * C/C++ source code generated on  : 14-Oct-2026 13:41:59
 */

#ifndef GOERTZEL_DATA_H
#define GOERTZEL_DATA_H

/* Include Files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#endif
/*
 * File trailer for goertzel_data.h
 *
 * [EOF]
 */
