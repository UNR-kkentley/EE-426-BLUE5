/*
 * File: goertzel_initialize.c
 *
 * MATLAB Coder version            : 26.2
 * C/C++ source code generated on  : 14-Oct-2026 13:41:59
 */

/* Include Files */
#include "goertzel_initialize.h"
#include "rt_nonfinite.h"

/* Function Definitions */
/*
 * Arguments    : void
 * Return Type  : void
 */
void goertzel_initialize(void)
{
}

/*
 * File trailer for goertzel_initialize.c
 *
 * [EOF]
 */
