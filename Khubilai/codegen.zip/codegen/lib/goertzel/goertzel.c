/*
 * File: goertzel.c
 *
 * MATLAB Coder version            : 26.2
 * C/C++ source code generated on  : 14-Oct-2026 13:41:59
 */

/* Include Files */
#include "goertzel.h"
#include "rt_nonfinite.h"
#include <math.h>

/* Function Definitions */
/*
 * Arguments    : const double X[128]
 *                double INDVEC
 * Return Type  : creal_T
 */
creal_T goertzel(const double X[128], double INDVEC)
{
  creal_T Y;
  double complexConstant_im;
  double complexConstant_re;
  double cos2TwidFactor;
  double phaseCorrection_im;
  double phaseCorrection_re;
  double s0_re;
  double s1_im;
  double s1_re;
  double s2_im;
  double twiddleFactor;
  int ind;
  twiddleFactor = 6.283185307179586 * (INDVEC - 1.0) / 128.0;
  cos2TwidFactor = 2.0 * cos(twiddleFactor);
  phaseCorrection_re = twiddleFactor * 0.0;
  if (phaseCorrection_re == 0.0) {
    complexConstant_re = cos(-twiddleFactor);
    complexConstant_im = sin(-twiddleFactor);
  } else if (-twiddleFactor == 0.0) {
    complexConstant_re = rtNaN;
    complexConstant_im = 0.0;
  } else {
    complexConstant_re = rtNaN;
    complexConstant_im = rtNaN;
  }
  phaseCorrection_re *= 127.0;
  phaseCorrection_im = 127.0 * -twiddleFactor;
  if (phaseCorrection_re == 0.0) {
    phaseCorrection_re = cos(phaseCorrection_im);
    phaseCorrection_im = sin(phaseCorrection_im);
  } else if (phaseCorrection_im == 0.0) {
    phaseCorrection_im = 0.0;
  } else {
    phaseCorrection_im = rtNaN;
  }
  s1_re = 0.0;
  s1_im = 0.0;
  twiddleFactor = 0.0;
  s2_im = 0.0;
  for (ind = 0; ind < 127; ind++) {
    double s0_im;
    s0_re = (X[ind] + cos2TwidFactor * s1_re) - twiddleFactor;
    s0_im = cos2TwidFactor * s1_im - s2_im;
    twiddleFactor = s1_re;
    s2_im = s1_im;
    s1_re = s0_re;
    s1_im = s0_im;
  }
  s0_re = ((X[127] + cos2TwidFactor * s1_re) - twiddleFactor) -
          (s1_re * complexConstant_re - s1_im * complexConstant_im);
  twiddleFactor = (cos2TwidFactor * s1_im - s2_im) -
                  (s1_re * complexConstant_im + s1_im * complexConstant_re);
  Y.re = s0_re * phaseCorrection_re - twiddleFactor * phaseCorrection_im;
  Y.im = s0_re * phaseCorrection_im + twiddleFactor * phaseCorrection_re;
  return Y;
}

/*
 * File trailer for goertzel.c
 *
 * [EOF]
 */
