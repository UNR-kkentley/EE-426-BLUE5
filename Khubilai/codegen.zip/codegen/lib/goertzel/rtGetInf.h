/*
 * File: rtGetInf.h
 *
 * MATLAB Coder version            : 26.2
 * C/C++ source code generated on  : 14-Oct-2026 13:41:59
 */

#ifndef RTGETINF_H
#define RTGETINF_H

/* Include Files */
#include "rtwtypes.h"

#ifdef __cplusplus
extern "C" {
#endif

extern real_T rtGetInf(void);
extern real32_T rtGetInfF(void);
extern real_T rtGetMinusInf(void);
extern real32_T rtGetMinusInfF(void);

#ifdef __cplusplus
}
#endif
#endif
/*
 * File trailer for rtGetInf.h
 *
 * [EOF]
 */
