/*
 * File: _coder_goertzel_api.h
 *
 * MATLAB Coder version            : 26.2
 * C/C++ source code generated on  : 14-Oct-2026 13:41:59
 */

#ifndef _CODER_GOERTZEL_API_H
#define _CODER_GOERTZEL_API_H

/* Include Files */
#include "emlrt.h"
#include "mex.h"
#include "tmwtypes.h"
#include <string.h>

/* Variable Declarations */

#ifdef __cplusplus
extern "C" {
#endif

extern emlrtCTX emlrtRootTLSGlobal;
extern emlrtContext emlrtContextGlobal;

#ifdef __cplusplus
}
#endif

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
creal_T goertzel(const real_T X[128], real_T INDVEC);

void goertzel_api(const mxArray *const prhs[2], const mxArray **plhs);

void goertzel_atexit(void);

void goertzel_initialize(void);

void goertzel_terminate(void);

void goertzel_xil_shutdown(void);

void goertzel_xil_terminate(void);

#ifdef __cplusplus
}
#endif

#endif
/*
 * File trailer for _coder_goertzel_api.h
 *
 * [EOF]
 */
