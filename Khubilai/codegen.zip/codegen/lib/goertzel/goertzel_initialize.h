/*
 * File: goertzel_initialize.h
 *
 * MATLAB Coder version            : 26.2
 * C/C++ source code generated on  : 14-Oct-2026 13:41:59
 */

#ifndef GOERTZEL_INITIALIZE_H
#define GOERTZEL_INITIALIZE_H

/* Include Files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
extern void goertzel_initialize(void);

#ifdef __cplusplus
}
#endif

#endif
/*
 * File trailer for goertzel_initialize.h
 *
 * [EOF]
 */
