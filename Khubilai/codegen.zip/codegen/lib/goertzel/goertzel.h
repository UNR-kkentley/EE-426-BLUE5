/*
 * File: goertzel.h
 *
 * MATLAB Coder version            : 26.2
 * C/C++ source code generated on  : 14-Oct-2026 13:41:59
 */

#ifndef GOERTZEL_H
#define GOERTZEL_H

/* Include Files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
extern creal_T goertzel(const double X[128], double INDVEC);

#ifdef __cplusplus
}
#endif

#endif
/*
 * File trailer for goertzel.h
 *
 * [EOF]
 */
