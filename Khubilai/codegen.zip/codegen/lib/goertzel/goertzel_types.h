/*
 * File: goertzel_types.h
 *
 * MATLAB Coder version            : 26.2
 * C/C++ source code generated on  : 14-Oct-2026 13:41:59
 */

#ifndef GOERTZEL_TYPES_H
#define GOERTZEL_TYPES_H

/* Include Files */
#include "rtwtypes.h"

#endif
/*
 * File trailer for goertzel_types.h
 *
 * [EOF]
 */
